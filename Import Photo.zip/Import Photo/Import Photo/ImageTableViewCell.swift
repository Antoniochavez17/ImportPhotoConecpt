//
//  ImageTableViewCell.swift
//  Import Photo
//
//  Created by Antonio Adrian Chavez on 4/5/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class ImageTableViewCell: UITableViewCell {



    @IBOutlet weak var ImageCells: UIImageView!
    @IBOutlet weak var TitleCells: UILabel!
    @IBOutlet weak var CreditCells: UILabel!
    @IBOutlet weak var ImportViewBackground: UIView!
    @IBOutlet weak var ImportCells: UIButton!
    @IBAction func ImportCellsAction(_ sender: Any) {
        
        
        
    }
    @IBOutlet weak var CardBackground: UIView!
    
    @IBOutlet weak var importLBL: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
