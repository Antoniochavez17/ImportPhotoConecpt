//
//  ViewController.swift
//  Import Photo
//
//  Created by Antonio Adrian Chavez on 4/5/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var UITableView: UITableView!
    
    let titleLbl = ["iOS Wallpaper", "iPadOS Wallpaper", "iOS Wallpaper"]
    let creditlbl = ["@AR72014", "@Apple", "@EvgeniyZemelko"]
    let image = ["Image", "Image-2", "Image-1"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.navigationItem.title = "Wallpaper"
        self.UITableView.separatorStyle = UITableViewCell.SeparatorStyle.none
    }


}


extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 335
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleLbl.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
         let imageTableView = UITableView.dequeueReusableCell(withIdentifier: "Image", for: indexPath) as? ImageTableViewCell
        
        // Image
        imageTableView?.ImageCells.image = UIImage(named: image[indexPath.row])
        
        // Title
        imageTableView?.TitleCells.text = titleLbl[indexPath.row]
        
        // Credit
        imageTableView?.CreditCells.text = "By: \(creditlbl[indexPath.row])"
    
        
        
        // SF Symbol
        let imageAttachment = NSTextAttachment()
        imageAttachment.image = UIImage(systemName: "square.and.arrow.down")?.withTintColor(.white)
        

        let fullString = NSMutableAttributedString(string: "")
        fullString.append(NSAttributedString(attachment: imageAttachment))
        fullString.append(NSAttributedString(string: " Import"))
        imageTableView?.importLBL.attributedText = fullString
        
        
         imageTableView?.ImportCells.addTarget(self,action: #selector(clicked),for: .touchUpInside)
         imageTableView?.ImportCells.tag = indexPath.row
        
        imageTableView?.ImportViewBackground.layer.cornerRadius = 5
        
        imageTableView?.ImportViewBackground.layer.masksToBounds = true
        
    
        imageTableView?.CardBackground.layer.cornerRadius = 5
        
        imageTableView?.CardBackground.layer.masksToBounds = true
        
        return imageTableView!
        
    }
    
    
    @objc func clicked (_ btn: UIButton) {
     
      
    }
    
    
    
}
